# Photosynthesis

## Content Priority Outline

1. Trailer
2. Title
3. Release Date(s)
4. Buy Tickets
5. Rating
6. "Fine print"
