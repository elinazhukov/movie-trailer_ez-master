// Lettering
$('h1').lettering();

// Video Player
$('video').mediaelementplayer();